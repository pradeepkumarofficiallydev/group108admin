import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Newtextstyle {

  // static TextStyle bodyText(Color myColor) {
  //   return GoogleFonts.lato(
  //       textStyle: GoogleFonts.lato(
  //           textStyle: TextStyle(
  //             fontSize: 12.sp,
  //             color: myColor,
  //             fontWeight: FontWeight.w400,
  //           )
  //       )
  //   );
  // }
  // static TextStyle bodyTextSemibold(Color myColor) {
  //   return GoogleFonts.lato(
  //       textStyle: GoogleFonts.lato(
  //           textStyle: TextStyle(
  //             fontSize: 12.sp,
  //             color: myColor,
  //             fontWeight: FontWeight.w700,
  //           )
  //       )
  //   );
  // }
  //
  // static TextStyle subHeading2(Color myColor) {
  //   return GoogleFonts.lato(
  //       textStyle: GoogleFonts.lato(
  //           textStyle: TextStyle(
  //             fontSize: 12.sp,
  //             color: myColor,
  //             fontWeight: FontWeight.w600,
  //           )
  //       )
  //   );
  // }
  // static TextStyle subHeading3(Color myColor) {
  //   return GoogleFonts.lato(
  //       textStyle: GoogleFonts.lato(
  //           textStyle: TextStyle(
  //             fontSize: 14.sp,
  //             color: myColor,
  //             fontWeight: FontWeight.bold,
  //           )
  //       )
  //   );
  // }
  //
  //
  //
  // static TextStyle subHeading4(Color myColor) {
  //   return GoogleFonts.lato(
  //       textStyle: GoogleFonts.lato(
  //           textStyle: TextStyle(
  //             fontSize: 16.sp,
  //             color: myColor,
  //             fontWeight: FontWeight.bold,
  //           )
  //       )
  //   );
  // }
  //
  //
  // static TextStyle pricingThumbail(Color myColor) {
  //   return GoogleFonts.lato(
  //       textStyle: GoogleFonts.lato(
  //           textStyle: TextStyle(
  //             fontSize: 12.sp,
  //             color: myColor,
  //             fontWeight: FontWeight.bold,
  //           )
  //       )
  //   );
  // }
  // static TextStyle pricingProductPage(Color myColor) {
  //   return GoogleFonts.lato(
  //       textStyle: GoogleFonts.lato(
  //           textStyle: TextStyle(
  //             fontSize: 14.sp,
  //             color: myColor,
  //             fontWeight: FontWeight.bold,
  //           )
  //       )
  //   );
  // }
  // static TextStyle minorText(Color myColor) {
  //   return GoogleFonts.lato(
  //       textStyle: GoogleFonts.lato(
  //           textStyle: TextStyle(
  //             fontSize: 10.sp,
  //             color: myColor,
  //             fontWeight: FontWeight.normal,
  //           )
  //       )
  //   );
  // }
  // static TextStyle minorTextBold(Color myColor) {
  //   return GoogleFonts.lato(
  //       textStyle: GoogleFonts.lato(
  //           textStyle: TextStyle(
  //             fontSize: 10.sp,
  //             color: myColor,
  //             fontWeight: FontWeight.bold,
  //           )
  //       )
  //   );
  // }
  // static TextStyle title1(Color myColor) {
  //   return GoogleFonts.lato(
  //       textStyle: GoogleFonts.lato(
  //           textStyle: TextStyle(
  //             fontSize: 24.sp,
  //             color: myColor,
  //             fontWeight: FontWeight.bold,
  //           )
  //       )
  //   );
  // }
  // static TextStyle bigText(Color myColor) {
  //   return GoogleFonts.lato(
  //       textStyle: GoogleFonts.lato(
  //           textStyle: TextStyle(
  //             fontSize: 14.sp,
  //             color: myColor,
  //             fontWeight: FontWeight.normal,
  //           )
  //       )
  //   );
  // }
  // static TextStyle buttonText(Color myColor) {
  //   return GoogleFonts.lato(
  //       textStyle: GoogleFonts.lato(
  //           textStyle: TextStyle(
  //             fontSize: 12.sp,
  //             color: myColor,
  //             fontWeight: FontWeight.w600,
  //           )
  //       )
  //   );
  // }
  // static TextStyle h2(Color myColor) {
  //   return GoogleFonts.lato(
  //       textStyle: GoogleFonts.lato(
  //           textStyle: TextStyle(
  //             fontSize: 28.sp,
  //             color: myColor,
  //             fontWeight: FontWeight.bold,
  //           )
  //       )
  //   );
  // }
  // static TextStyle chattext(Color myColor) {
  //   return GoogleFonts.lato(
  //       textStyle: GoogleFonts.lato(
  //           textStyle: TextStyle(
  //             fontSize: 14.sp,
  //             color: myColor,
  //             fontWeight: FontWeight.bold,
  //           )
  //       )
  //   );
  // }
  // static TextStyle pageTitle(Color myColor) {
  //   return GoogleFonts.lato(
  //       textStyle: GoogleFonts.lato(
  //           textStyle: TextStyle(
  //             fontSize: 18.sp,
  //             color: myColor,
  //             fontWeight: FontWeight.bold,
  //           )
  //       )
  //   );
  // }
  // static TextStyle interText9(Color myColor) {
  //   return GoogleFonts.inter(
  //       textStyle: GoogleFonts.inter(
  //           textStyle: TextStyle(
  //             fontSize: 9.sp,
  //             color: myColor,
  //             fontWeight: FontWeight.w600,
  //           )
  //       )
  //   );
  // }
  // static TextStyle interText10(Color myColor) {
  //   return GoogleFonts.inter(
  //          textStyle: GoogleFonts.inter(
  //           textStyle: TextStyle(
  //             fontSize: 10.sp,
  //             color: myColor,
  //             fontWeight: FontWeight.w600,
  //           )
  //       )
  //   );
  // }
  // static TextStyle nanoText14Normal(Color myColor) {
  //   return GoogleFonts.notoSans(
  //       textStyle: GoogleFonts.notoSans(
  //           textStyle: TextStyle(
  //             fontSize: 14.sp,
  //             color: myColor,
  //             fontWeight: FontWeight.w400,
  //           )
  //       )
  //   );
  // }
  // static TextStyle nanoText14Medium(Color myColor) {
  //   return GoogleFonts.notoSans(
  //       textStyle: GoogleFonts.notoSans(
  //           textStyle: TextStyle(
  //             fontSize: 14.sp,
  //             color: myColor,
  //             fontWeight: FontWeight.w500,
  //           )
  //       )
  //   );
  // }
  // static TextStyle nanoText16Normal(Color myColor) {
  //   return GoogleFonts.notoSans(
  //       textStyle: GoogleFonts.notoSans(
  //           textStyle: TextStyle(
  //             fontSize: 16.sp,
  //             color: myColor,
  //             fontWeight: FontWeight.w400,
  //           )
  //       )
  //   );
  // }
  // static TextStyle nanoText20Normal(Color myColor) {
  //   return GoogleFonts.notoSans(
  //       textStyle: GoogleFonts.notoSans(
  //           textStyle: TextStyle(
  //             height: 1.0,
  //             letterSpacing: 1.0,
  //             fontSize: 18.sp,
  //             color: myColor,
  //             fontWeight: FontWeight.w500,
  //
  //
  //           )
  //       )
  //   );
  // }
  // static TextStyle nanoText20Bold(Color myColor) {
  //   return GoogleFonts.notoSans(
  //       textStyle: GoogleFonts.notoSans(
  //           textStyle: TextStyle(
  //             fontSize: 18.sp,
  //             color: myColor,
  //             fontWeight: FontWeight.w700,
  //           )
  //       )
  //   );
 // }
  static TextStyle nanoText18Bold(Color myColor,double height) {
    return GoogleFonts.notoSansDevanagari(
        textStyle: GoogleFonts.notoSansDevanagari(
            textStyle: TextStyle(
              fontSize: height,
              color: myColor,
              fontWeight: FontWeight.w700,
            )
        )
    );
  }

  static TextStyle privacyTitleTextbold(Color myColor,double height) {
    return GoogleFonts.notoSansDevanagari(
        textStyle: GoogleFonts.notoSansDevanagari(
            textStyle: TextStyle(
              fontSize: height,
              color: myColor,
              fontWeight: FontWeight.w700,
            )
        )
    );
  }




  static TextStyle privacyTitleTextnorml(Color myColor,double height) {
    return GoogleFonts.notoSansDevanagari(
        textStyle: GoogleFonts.notoSansDevanagari(
            textStyle: TextStyle(
              fontSize: height,
              color: myColor,
              fontWeight: FontWeight.w500,
            )
        )
    );
  }








  static TextStyle normaNoSpacingboldlopenSans(Color myColor,double height) {
    return GoogleFonts.notoSansDevanagari(
        textStyle: GoogleFonts.notoSansDevanagari(
            textStyle: TextStyle(
              wordSpacing: 0.0, // Adjust spacing between words
              height: 1, // Spacing between lines


              fontSize: height,
              color: myColor,
              fontWeight: FontWeight.w700,
            )
        )
    );
  }





  static TextStyle normalopenSans(Color myColor, double height) {
    return GoogleFonts.notoSansDevanagari(
        textStyle: GoogleFonts.notoSansDevanagari(
            textStyle: TextStyle(
              //letterSpacing: 2.0,
              wordSpacing: 5.0, // Adjust spacing between words

              height: 1.5, // Spacing between lines

              fontSize:height,
              color: myColor,
              fontWeight: FontWeight.w500,
            )
        )
    );
  }



  static TextStyle normaNoSpacinglopenSans(Color myColor, double height) {
    return


      GoogleFonts.notoSansDevanagari(
        textStyle: GoogleFonts.notoSansDevanagari(
           textStyle:

    TextStyle(
              //letterSpacing: 2.0,
             /// wordSpacing: 5.0, // Adjust spacing between words


             // fontFamily: 'Maine',
              fontSize:height,
              color: myColor,
              fontWeight: FontWeight.w500,
           )
       )
    );
  }





}