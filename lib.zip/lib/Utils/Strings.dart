 import 'dart:ui';

class  Strings
 {



   static const baseUrl="https://jsp.socialpost.co.in/api/";



   //static  const fo ="w400";

   //
   // FontWeight.normal
   // fontWeight: FontWeight.normal;


   static  const FontWeight  mytextfontweight =  FontWeight.w400;
   static  const FontWeight  mytext_heading_fontweight =  FontWeight.bold;

   // static  const FontWeight  DotsDecoratorColor =  FontWeight.w400;


   static  const  double  my_app_font_size=16;
   static  const  double  my_app_heading_font_size=18;
   static  const  String  policy="Terms of cancellation The Users or the Owner agree and acknowledge that they shall not be entitled to cancel or reschedule the booking for a Charging Session. Any cancellation or rescheduling by the Users or the Owner shall be subject to payment of Cancellation Fee as mentioned in this section.";






 // static  const FontSi  mytextfontweight =  FontWeight.w400;


 ///// f FontWeight.w400;


 }