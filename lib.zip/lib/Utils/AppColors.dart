import 'dart:ui';

import 'package:flutter/material.dart';

class AppColor
{


  static  const Color  textcolor =  Colors.white;

  static  const Color  whitecolor =  Colors.white;


  static  const Color  appColor=Color(0xFFf2902d);
  static  const  Color   app_toll_bar_color =Color(0XFF363435);

  static  const  Color   DotsDecoratorColor =Color(0xFF05FF46);

  static  const  Color   activebtncolor =Color(0xFF05FF46);

  static  const  Color   apptextcolor =Colors.black;

  static  const  Color   blackcolor =Colors.black;
  static  const  Color   grayColor =Color(0xFFdcdcdc);


  static  const  Color   activebtncoloSSr =Color(0xF5F4F3F7);





// static  const  Color   activebtncolor =Color(0xFF05FF46);




















}