






import 'package:form_field_validator/form_field_validator.dart';


import 'package:flutter/material.dart';
import 'package:get/get_state_manager/src/simple/get_state.dart';
import 'package:jsp/Utils/AppColors.dart';

import '../Utils/NewTextstyle.dart';
import '../Utils/custom_widgets.dart';
import '../controller/LoginController.dart';
import 'OTPVerificationScree.dart';

class Loginscreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: BannerScreen(),
    );
  }
}

class BannerScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {


    double width = MediaQuery.of(context).size.width * 0.24; // Responsive width
    double height = width * 0.4; // Maintain aspect ratio



    return Scaffold(
      backgroundColor: Colors.white,

      body: SingleChildScrollView(

        child:





        GetBuilder<LoginController>(
          init: LoginController(),
          builder: (s) =>






              Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            // Banner Section
            Stack(
              children: [
                // Banner Image
                Container(
                  width: double.infinity,
                  height: height * 10.4, // Adjust the height as needed
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: AssetImage('assets/images/banner.png'), // Your uploaded banner
                      fit: BoxFit.cover,
                    ),
                  ),
                ),

                // Overlay Text
                Align(

                  alignment: Alignment.center,

                  //   top: screenWidth * 0.05,
                  // //  left: screenWidth * 0.05,
                  //   bottom: screenHeight * 0.02,
                  child:



                  Container(

                    padding: EdgeInsets.only(top: height*.8),

                    child: Column(crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [


                        Container(
                          height: height*1.4,
                          alignment: Alignment.center,
                          child: Text(
                            textAlign: TextAlign.start,

                            "जन सहमति पार्टी",
                            style: Newtextstyle.normalopenSans(Colors.white,height*1.1),),



                        ),
                        Container(
                          alignment: Alignment.center,
                          child: Text(
                            '"जनता की सहमति, लोकतंत्र की मजबूती"',

                            style: Newtextstyle.normaNoSpacinglopenSans(Colors.black,height*.45),
                            textAlign: TextAlign.start,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),


                Positioned(

                  top: height*6,
                  right: height*.4,


                  //height: screenHeight/2,
                  //  top: 30,
                  // bottom: 0,

                  child: Text(
                    '" बिहार के लिए,\n             हर कदम सही! "',
                    textAlign: TextAlign.center,
                    style: Newtextstyle.normaNoSpacingboldlopenSans(Colors.white,height*.7),
                  ),
                ),


              ],
            ),

            // Content Section
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(height: height * 0.4),

                Text(
                  "आप का स्वागत है",
                  style: Newtextstyle.normaNoSpacingboldlopenSans(Colors.black,height*.7),

                ),
                SizedBox(height: height * 0.3),
                Text(
                  "मोबाइल नंबर दर्ज करे",
                  style: Newtextstyle.normaNoSpacinglopenSans(Colors.black,height*.5),

                ),

                // Mobile Number Input
                //SizedBox(height: height * 0.6),
                Container(

                  margin: EdgeInsets.all( height*.8),

                  height: height * 1.2,
                  decoration: BoxDecoration(
                    color: AppColor.appColor,

                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.orange, width: 2),
                  ),
                  child: Row(
                    children: [
                      Padding(

                        padding: EdgeInsets.symmetric(horizontal: height*.5),
                        child: Text(
                          "+91 |",
                          style: Newtextstyle.normaNoSpacingboldlopenSans(AppColor.blackcolor,height*.5),




                        ),
                      ),
                      Expanded(
                        child: TextFormField(


                          validator: MultiValidator([
                            MinLengthValidator(10,
                                errorText:
                                'Enter 10 digit Mobile Number'),
                            RequiredValidator(
                                errorText: 'Enter mobile number'),
                            /*    PatternValidator(r'(^[0,9]{10}$)',
                                  errorText: 'enter vaid mobile number'),*/
                          ]),
                          maxLength: 10,
                          cursorColor: Colors.black,
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            counterText: '',
                          ///  filled: true,
                            hintText: "**********",

                         //   fillColor: Colors.white,
                            contentPadding:
                            const EdgeInsets.only(
                                left: 14.0,
                                bottom: 6.0,
                                top: 8.0),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0),
                            ),

                            enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0),
                            ),
                          ),
                          controller:s. mobileno_controller,

                          style: Newtextstyle.normaNoSpacingboldlopenSans(AppColor.blackcolor,height*.4),
                          //
                          // keyboardType: TextInputType.number,
                          // decoration: InputDecoration(
                          //   hintText: "**********",
                          //   border: InputBorder.none,
                          // ),




                        ),
                      ),
                    ],
                  ),
                ),

                // Proceed Button
                SizedBox(height: height * 0.8),


               s. isLoading.value ?

                CustomWidgets.showCircularIndicator1(context,height*.9,AppColor.appColor):




                      ElevatedButton(
                  onPressed: () {




                    // s.User_Login_fun();
                    //

                  //
                  //
                  // Navigator.push(
                  //   context,
                  //   MaterialPageRoute(builder: (context) => OTPVerificationScreen()),);
                  //


                    if(s.isInputValid(s.mobileno_controller.text)){





                      s.  User_Login_fun();





                    }





                    else{


                     s. showInputError( s.mobileno_controller.text );




                    }




                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.grey.shade200,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(25),
                    ),
                    side: BorderSide(color: AppColor.appColor, width: 2.5),
                    padding: EdgeInsets.symmetric(
                      horizontal: height * .7,
                      vertical: height * .2,
                    ),
                  ),
                  child: Text(
                    "आगे बढ़े",




                    style: Newtextstyle.normaNoSpacingboldlopenSans(AppColor.blackcolor,height*.6),



                  ),
                ),


              ],
            ),
          ],
        ),
      ),
      )
    );
  }
}




















