import 'package:flutter/material.dart';

import 'IDCardScreen.dart';


class RegistrationForm extends StatefulWidget {
  @override
  _RegistrationFormState createState() => _RegistrationFormState();
}

class _RegistrationFormState extends State<RegistrationForm> {
  // Controllers for each TextField
  final TextEditingController cityController = TextEditingController();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController mobileController = TextEditingController();
  final TextEditingController dobController = TextEditingController();
  final TextEditingController stateController = TextEditingController();
  final TextEditingController districtController = TextEditingController();
  final TextEditingController constituencyController = TextEditingController();
  final TextEditingController pinCodeController = TextEditingController();
  final TextEditingController addressController = TextEditingController();

  @override
  void dispose() {
    // Dispose controllers when not needed to avoid memory leaks
    cityController.dispose();
    nameController.dispose();
    mobileController.dispose();
    dobController.dispose();
    stateController.dispose();
    districtController.dispose();
    constituencyController.dispose();
    pinCodeController.dispose();
    addressController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(


        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/background.jpg'), // Replace with your background image
            fit: BoxFit.cover,
          ),
        ),
        width: double.infinity,

        child: SafeArea(
          child: SingleChildScrollView(
            child: Container(




              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.arrow_back, color: Colors.white),
                  SizedBox(height: 20),
                  Text(
                    "आओ जुड़ें,\nऔर नये समाज का निर्माण करें",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 20),
                  _buildTextField("शहर", cityController),
                  _buildTextField("नाम", nameController),
                  _buildTextField("+91 मोबाइल नंबर दर्ज करें", mobileController, keyboardType: TextInputType.phone),
                  _buildDateField("जन्म तिथि", dobController),
                  _buildTextField("बिहार", stateController),
                  _buildTextField("जिला", districtController),
                  _buildTextField("निर्वाचन क्षेत्र", constituencyController),
                  _buildTextField("पिन कोड", pinCodeController, keyboardType: TextInputType.number),
                  _buildTextField("पता", addressController),
                  SizedBox(height: 20),
                  Container(

                    decoration: BoxDecoration(



                    ),
                    height: 40,

                     width: 150,
                    alignment: Alignment.centerLeft,

                    child: ElevatedButton.icon(
                      onPressed: () {
                        // Handle photo upload logic here
                      },




                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.black, // Button background color
                        minimumSize: Size(double.infinity, 50),
                        side: BorderSide(color: Colors.white, width: 2), // Border customization
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0), // Rounded corners
                        ),
                      ),
                      //icon: Icon(Icons.photo_camera),
                      label: Text("फोटो अपलोड करें",style: TextStyle(color: Colors.white),),

                      // style: ElevatedButton.styleFrom(
                      //   foregroundColor: Colors.white, backgroundColor: Colors.black,
                      //   minimumSize: Size(double.infinity, 50),
                      // ),
                    ),
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {
                      // Handle form submission logic
                      print("City: ${cityController.text}");
                      print("Name: ${nameController.text}");
                      print("Mobile: ${mobileController.text}");
                      print("DOB: ${dobController.text}");
                      print("State: ${stateController.text}");
                      print("District: ${districtController.text}");
                      print("Constituency: ${constituencyController.text}");
                      print("Pin Code: ${pinCodeController.text}");
                      print("Address: ${addressController.text}");






                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => IDCardScreen()),);



                    },
                    child: Text("सबमिट करें" ,style: TextStyle(
                      color: Colors.black,
                      fontSize: 20,
                    ),),
                    style: ElevatedButton.styleFrom(
                      foregroundColor: Colors.black,
                      backgroundColor: Colors.white,
                      minimumSize: Size(double.infinity, 50),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(String hintText, TextEditingController controller,
      {TextInputType keyboardType = TextInputType.text}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextField(
        controller: controller,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          filled: true,
          fillColor: Colors.white,
          hintText: hintText,
          hintStyle: TextStyle(
            color: Colors.black54,
            fontSize: 16,
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8.0),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }

  Widget _buildDateField(String hintText, TextEditingController controller) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextField(
        controller: controller,
        readOnly: true,
        onTap: () async {
          DateTime? pickedDate = await showDatePicker(
            context: context,
            initialDate: DateTime.now(),
            firstDate: DateTime(1900),
            lastDate: DateTime(2100),
          );
          if (pickedDate != null) {
            setState(() {
              controller.text = "${pickedDate.day}-${pickedDate.month}-${pickedDate.year}";
            });
          }
        },

        decoration: InputDecoration(
          filled: true,
          fillColor: Colors.white,
          hintText: hintText,
          hintStyle: TextStyle(
            color: Colors.black54,
            fontSize: 16,
          ),

          suffixIcon: Icon(Icons.calendar_today, color: Colors.grey),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8.0),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }
}
